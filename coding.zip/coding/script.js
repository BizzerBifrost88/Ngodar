
function scrollToSection(sectionId) {
    document.getElementById(sectionId).scrollIntoView({ behavior: 'smooth' });
}

document.addEventListener('DOMContentLoaded', () => {
    const loadingScreen = document.getElementById('loading-screen');
    setTimeout(() => {
        loadingScreen.style.display = 'none';
        document.body.style.overflow = 'auto'; // Enable scrolling after loading
    }, 2000); // Adjust time as needed (2 seconds here)

    // Add smooth scroll to navbar links
    document.querySelectorAll('header nav ul li a').forEach(link => {
        link.addEventListener('click', event => {
            event.preventDefault();
            const targetId = link.getAttribute('href').substring(1);
            scrollToSection(targetId);
        });
    });
});

document.addEventListener('scroll', () => {
    const sections = document.querySelectorAll('section');
    const header = document.querySelector('header');
    sections.forEach(section => {
        const rect = section.getBoundingClientRect();
        if (rect.top <= 100 && rect.bottom >= 100) {
            header.style.backgroundColor = window.getComputedStyle(section).getPropertyValue('--header-color');
        }
    });
});
